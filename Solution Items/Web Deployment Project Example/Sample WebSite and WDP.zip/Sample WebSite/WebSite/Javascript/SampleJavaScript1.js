﻿
Type.registerNamespace('Appian');

/* Map Icons
----------------------------------------------- */

function createStreetIcon(ratio)
{
    var size = calcIconScale({ 
        width: 37, 
        height: 44 
    }, ratio);

    var icon = new GIcon();
    icon.image = '/image/map_feature_pin.png';
    icon.shadow = '/image/map_shadow.png';
    icon.iconSize = new GSize(size.width, size.height);
    icon.shadowSize = new GSize(size.width, size.height);
    icon.iconAnchor = new GPoint(parseInt(size.width / 2), size.height);
    icon.infoWindowAnchor = new GPoint(parseInt(size.width / 2), 1);
    
    return icon;
}

function createPointIcon()
{
    var icon = new GIcon();
    icon.image = '/image/map_pin.png';
    icon.shadow = '/image/map_shadow.png';
    icon.iconSize = new GSize(27, 38);
    icon.shadowSize = new GSize(41, 38);
    icon.iconAnchor = new GPoint(14, 38);
    icon.infoWindowAnchor = new GPoint(12, 1);
    
    return icon;
}

function createTextIcon()
{
    var icon = new GIcon();
    icon.image = '/image/map_text_pin.png';
    icon.iconSize = new GSize(27, 38);
    icon.iconAnchor = new GPoint(14, 38);
    icon.infoWindowAnchor = new GPoint(45, 5);
    
    return icon;
}

function createStreetviewIcon()
{
    var icon = new GIcon();
    icon.image = '/image/map_pin_streetview.png';
    icon.iconSize = new GSize(6, 3);
    icon.iconAnchor = new GPoint(3, 2);
    icon.infoWindowAnchor = new GPoint(4, 1);
    
    return icon;
}

function createBillboardIcon()
{
    var icon = new GIcon();
    icon.iconAnchor = new GPoint(14, 38);
                    
    return icon;
}

function createReviewIcon(ratio)
{
    var size = calcIconScale({ 
        width: 27, 
        height: 38 
    }, ratio);

    var icon = new GIcon();   
    icon.image = '/image/map_pin.png';
    icon.shadow = '/image/map_shadow.png';
    icon.iconSize = new GSize(size.width, size.height);
    icon.shadowSize = new GSize(size.width, size.height);
    icon.iconAnchor = new GPoint(parseInt(size.width / 2), size.height);
    icon.infoWindowAnchor = new GPoint(parseInt(size.width / 2), 1);

    return icon;
}

function createCityIcon(ratio)
{
    var size = calcIconScale({ 
        width: 37, 
        height: 37 
    }, ratio);

    var offsetY = 8;

    var icon = new GIcon();    
    icon.image = '/image/map_pin_city.png';
    icon.iconSize = new GSize(size.width, size.height);
    icon.iconAnchor = new GPoint(parseInt(size.width / 2), size.height + offsetY);
    icon.infoWindowAnchor = new GPoint(parseInt(size.width / 2), 1);

    return icon;
}

function calcIconScale(size, ratio)
{
    var scaleW = parseInt(size.width * (parseInt(ratio) / 100));
    var scaleH = parseInt(size.height * (parseInt(ratio) / 100));
    
    size.width = Math.max(10, size.width + scaleW * 2);
    size.height = Math.max(10, size.height + scaleH * 2);
    
    return size;
}

/* Map Nav Control
----------------------------------------------- */
/*
function MapNavControl() {}

MapNavControl.prototype = new GControl();

MapNavControl.prototype.initialize = function(map)
{
    var container = document.createElement('div');
    container.className = 'MapNavControl';

    container.appendChild(AddMapControl(map, 'Pan Up', 'PanUp', function()
    {
        map.panDirection(0, 1);
    }));

    container.appendChild(AddMapControl(map, 'Pan Left', 'PanLeft', function()
    {
        map.panDirection(1, 0);
    }));

    container.appendChild(AddMapControl(map, 'Pan Right', 'PanRight', function()
    {
        map.panDirection(-1, 0);
    }));

    container.appendChild(AddMapControl(map, 'Pan Down', 'PanDown', function()
    {
        map.panDirection(0, -1);
    }));

    map.getContainer().appendChild(container);
    return container;
}

MapNavControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(100, 15));
}
*/


/* Map tip control to display helpful text
----------------------------------------------- */

function MapTipControl() {}

MapTipControl.prototype = new GControl();

MapTipControl.prototype.initialize = function(map)
{
    var container = document.createElement('div');
    container.className = 'MapTipControl';
    container.innerHTML = '<b>Tip:</b> Drag around the map or click on any street for more information!';

    // Hide tip is the map has been moved or clicked.

//    var me = this;
//    GEvent.addDomListener(container, 'click', function()
//    {
//        map.removeControl(me);
//        ASPCode.net.CookieManager.setCookie('MapTipControl', 'true', { expires: 30, path: '/'});
//    });

//    GEvent.addListener(map, 'click', function()
//    {
//        map.removeControl(me);
//        ASPCode.net.CookieManager.setCookie('MapTipControl', 'true', { expires: 30, path: '/'});
//    });
//    
//    GEvent.addListener(map, 'movestart', function()
//    {
//        map.removeControl(me);
//        ASPCode.net.CookieManager.setCookie('MapTipControl', 'true', { expires: 30, path: '/'});
//    });

    map.getContainer().appendChild(container);
    return container;
}

MapTipControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(235, 15));
}

/* Small Map Tip Control


function SmallMapTipControl() {}
SmallMapTipControl.prototype = new MapTipControl();
SmallMapTipControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(10, 45));
}

/* Text-based Markers
----------------------------------------------- */

function TextMarker(latlng, options){
    this.latlng = latlng;
    this.labelText = options.labelText || "";
    this.labelClass = options.labelClass || "MapTextTipControl";
    this.labelOffset = options.labelOffset || new GSize(0, 0);
    this.clickable = options.clickable || true;
    
    if (options.draggable) {
        // This version of TextMarker doesn't support dragging.
        options.draggable = false;
    }
    
    GMarker.apply(this, arguments);
}

TextMarker.prototype = new GMarker(new GLatLng(0, 0));

TextMarker.prototype.initialize = function(map) {

	GMarker.prototype.initialize.apply(this, arguments);

	var div = document.createElement("div");
	div.className = this.labelClass;
	div.innerHTML = this.labelText;
	div.style.position = "absolute";
	map.getPane(G_MAP_MARKER_PANE).appendChild(div);
	
	if (this.clickable) {
        var eventPassthrus = ['click', 'dblclick', 'mousedown', 'mouseup', 'mouseover', 'mouseout'];
        for(var i = 0; i < eventPassthrus.length; i++) {
                var name = eventPassthrus[i];
                GEvent.addDomListener(div, name, newEventPassthru(this, name));
        }
        
        // Mouseover behaviour for the cursor.
        div.style.cursor = "pointer";
    }

	this.map = map;
	this.div = div;
}

function newEventPassthru(obj, event) {
	return function() { 
		GEvent.trigger(obj, event);
	};
}

TextMarker.prototype.redraw = function(force) {
	GMarker.prototype.redraw.call(this, this.map);

	// We only need to do anything if the coordinate system has changed
	if (!force) return;

    if (this.div){
	    var p = this.map.fromLatLngToDivPixel(this.latlng);
	    var z = GOverlay.getZIndex(this.latlng.lat());

	    this.div.style.left = (p.x + this.labelOffset.width) + "px";
	    this.div.style.top = (p.y + this.labelOffset.height) + "px";
	    this.div.style.zIndex = z - 1; // Directly behind the marker image
	}
}

// Remove the main DIV from the map pane, destroy event handlers
TextMarker.prototype.remove = function() {
	GEvent.clearInstanceListeners(this.div);
	this.div.parentNode.removeChild(this.div);
	this.div = null;
	GMarker.prototype.remove.apply(this, arguments);
}

/* Map Zoom Control
----------------------------------------------- */

function MapZoomControl()
{
    this._className = 'LargeZoom';
    this._minZoom = 0;
    this._maxZoom = 19;
    this._mapBehaviour = null;
}

MapZoomControl.prototype = new GControl();

MapZoomControl.prototype.set_MapBehaviour = function(behaviour) 
{
    this._mapBehaviour = behaviour;
}

MapZoomControl.prototype.initialize = function(map) 
{
    var control = this;

    var container = document.createElement('div');
    container.className = 'MapZoomControl ' + this._className + 'Control';
    map.getContainer().appendChild(container);

//    var tmp = document.createElement('div');
//    container.appendChild(tmp);

    // Slider
    var textbox = document.createElement('input');
    textbox.type = 'text';
    textbox.className = this._className + 'Text';
    textbox.style.display = 'none';
    container.appendChild(textbox);

    var sliderBehaviour = $create(AjaxControlToolkit.SliderBehavior, {
        'EnableHandleAnimation' : false,
        'RailCssClass': this._className + 'Rail',
        'HandleCssClass': this._className + 'Handle',
        'HandleImageUrl':'/image/map_zoomhandle.gif',
        'Orientation': 0,
        'Minimum': this._minZoom,
        'Maximum': this._maxZoom,
        'Value': map.getZoom(),
        'RaiseChangeOnlyOnMouseUp': false}, {valueChanged : function(sender, e)
        {
            if (control._mapBehaviour)
            {
                control._mapBehaviour.setZoom(sender.get_Value());
            }
        }}, null, textbox);

    GEvent.addListener(map, 'moveend', function()
    {
        sliderBehaviour.set_Value(map.getZoom());
    });

    //tmp.appendChild(AddMapControl(map, 'Zoom Out', 'ZoomOut', function()
    container.insertBefore(AddMapControl(map, 'Zoom Out', 'ZoomOut', function()
    {
        if (control._mapBehaviour)
        {
            control._mapBehaviour.zoomOut();
        }

        sliderBehaviour.set_Value(map.getZoom());
    }), container.firstChild);

    container.appendChild(AddMapControl(map, 'Zoom In', 'ZoomIn', function()
    {
        if (control._mapBehaviour)
        {
            control._mapBehaviour.zoomIn();
        }

        sliderBehaviour.set_Value(map.getZoom());
    }));

    return container;
}

MapZoomControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(15, 15));
}

/* Small Map Zoom Control
----------------------------------------------- */

function SmallMapZoomControl()
{
    this._className = 'SmallZoom';
}
SmallMapZoomControl.prototype = new MapZoomControl();
SmallMapZoomControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_LEFT, new GSize(10, 10));
}

/* Map Type Control
----------------------------------------------- */

function MapTypeControl() 
{
    this._activeCSS = 'MapTypeControl MapTypeControl{0}';
    this._container;
}

MapTypeControl.prototype = new GControl();

MapTypeControl.prototype.initialize = function(map) 
{
    this._container = document.createElement('div');
    this._container.className = String.format(this._activeCSS, 'Hybrid');

    var control = this;
    this._container.appendChild(AddMapControl(map, 'Map', 'TypeMap', function()
    {
        this.parentNode.className = String.format(control._activeCSS, 'Map');
        map.setMapType(G_NORMAL_MAP);
    }));
    
    this._container.appendChild(AddMapControl(map, 'Satellite', 'TypeSat', function()
    {
        this.parentNode.className = String.format(control._activeCSS, 'Sat');
        map.setMapType(G_SATELLITE_MAP);
    }));
    
    this._container.appendChild(AddMapControl(map, 'Hybrid', 'TypeHybrid', function()
    {
        this.parentNode.className = String.format(control._activeCSS, 'Hybrid');
        map.setMapType(G_HYBRID_MAP);
    }));
    
    map.getContainer().appendChild(this._container);
    return this._container;
}

MapTypeControl.prototype.set_MapType = function(mapType) 
{
    this._container.className = String.format(this._activeCSS, mapType);
}

MapTypeControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_RIGHT, new GSize(117, 15));
}

/* Map StreetView Control
----------------------------------------------- */

function MapStreetViewControl() 
{
    this._mapBehaviour = null;
    this._container = null;
    this._control = null;
    this._activeCssClass = 'MapStreetViewControlActive';
}

MapStreetViewControl.prototype = new GControl();

MapStreetViewControl.prototype.initialize = function(map) 
{
    this._container = document.createElement('div');
    this._container.className = String.format('MapStreetViewControl');
    this._container.style.display = 'none';

    var $this = this;
    this._control = AddMapControl(map, 'Street View', 'TypeStreetView', function()
    {
        Sys.UI.DomElement.toggleCssClass($this._container, $this._activeCssClass);
        $this._mapBehaviour.toggleStreetView();
    })
    
    this._container.appendChild(this._control);
    
    map.getContainer().appendChild(this._container);
    return this._container;
}

MapStreetViewControl.prototype.set_MapBehaviour = function(behaviour) 
{
    this._mapBehaviour = behaviour;
}

MapStreetViewControl.prototype.set_Active = function(value)
{
    value ? Sys.UI.DomElement.addCssClass(this._container, this._activeCssClass) : Sys.UI.DomElement.removeCssClass(this._container, this._activeCssClass);
}

MapStreetViewControl.prototype.set_Visible = function(value)
{
    this._container.style.display = value ? 'block' : 'none';
}

MapStreetViewControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_RIGHT, new GSize(332, 15));
}

/* Map Control Helper
----------------------------------------------- */

function AddMapControl(map, title, cssClass, clickEvent)
{
    var control = document.createElement('div');
    control.title = title;
    control.className = cssClass;
    GEvent.addDomListener(control, 'click', clickEvent);
    GEvent.addDomListener(control, 'mouseover', function()
    {
        control.className = String.format('{0} {0}Hover', cssClass);
    });
    GEvent.addDomListener(control, 'mouseout', function()
    {
        control.className = cssClass;
    });
    
    return control;
}

/* Map Browse Control
----------------------------------------------- */

function MapOpenControl() {}

MapOpenControl.prototype = new GControl();

MapOpenControl.prototype.initialize = function(map) 
{
    var container = document.createElement('div');
    container.className = 'MapOpenControl';

    container.appendChild(AddMapControl(map, 'Browse Map', 'EnlargeMap', function()
    {
        var options;
        if (_streetData) options = {'StreetData' : _streetData};
    
        var init = openModalMap(options);
        if (init)
        {           
            // Update small map when ModalMap closes.
            _mapModal.get_events().addHandler('hide', syncSmallMap);
        }
    }));

    map.getContainer().appendChild(container);
    return container;
}

MapOpenControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_RIGHT, new GSize(0, 0));
}

function syncSmallMap()
{
    var map = $find('map$SmallMapBehavior');
    if (map == null)
    {
        map = $find('map$MediumMapBehavior');
    }
    if (map != null)
    {
        if (_streetData)
        {
            map.set_StreetData(_streetData);
        }
        map.updateMap();
    }
}

/* Close Control
----------------------------------------------- */

function MapCloseControl() {}

MapCloseControl.prototype = new GControl();

MapCloseControl.prototype.initialize = function(map) 
{
    var container = document.createElement('div');
    container.className = 'MapCloseControl';

    container.appendChild(AddMapControl(map, 'Close Map', 'CloseMap', function()
    {
        closeModalMap();
    }));

    map.getContainer().appendChild(container);
    return container;
}

MapCloseControl.prototype.getDefaultPosition = function()
{
    return new GControlPosition(G_ANCHOR_TOP_RIGHT, new GSize(15, 15));
}

/* Map Behavior
----------------------------------------------- */

var markerList = [];

Appian.MapBehavior = function(element)
{
    Appian.MapBehavior.initializeBase(this, [element]);
    
    this._latitude = 0;
    this._longitude = 0;
    this._zoom = 16;

    this._map = null;
}

Appian.MapBehavior.prototype = {

    initialize : function()
    {
        Appian.MapBehavior.callBaseMethod(this, 'initialize');
    },
    
    dispose : function()
    {
        var e = this.get_element();

        if (window.GUnload)
        {
            try { GUnload() } catch(e) {}; // 2.76 bug
        }

        Appian.MapBehavior.callBaseMethod(this, 'dispose');
    },

    loadMap: function()
    {
        // Google Map
        this._map = new GMap2(this.get_element());
        this._map.setCenter(new GLatLng(this._latitude, this._longitude), this._zoom, G_HYBRID_MAP);
    },

    updateMap: function()
    {
        if (this._map)
        {
            this.resetView();
            this.resetOverlays();
        }
    },

    resetView: function()
    {
        this._map.setCenter(new GLatLng(this._latitude, this._longitude), this._zoom);
    },
    
    resetOverlays: function()
    {
        this._map.clearOverlays();
        Array.clear(markerList);
    },
    
    resize : function()
    {
        this._map.checkResize();
    },
    
    zoomIn: function()
    {
        this._map.zoomIn();
    },
    
    zoomOut: function()
    {
        this._map.zoomOut();
    },
    
    setZoom: function(value)
    {
        this._map.setZoom(value);
    },
    
    getMapRadius: function(widthPercent, unlimited)
    {
        if(!widthPercent)widthPercent = 1;
        var bounds = this._map.getBounds();
        var northEast = bounds.getNorthEast();
        var southWest = bounds.getSouthWest();
        var km = (northEast.distanceFrom(southWest) / 1000) * widthPercent;
        if(unlimited){
            return Math.ceil(km / 2);
        }else{
            return Math.min(3000, Math.ceil(km / 2));
        }
    },

    add_Marker : function(marker)
    {
        this._map.addOverlay(marker);
        Array.add(markerList, marker);
    },

    remove_Marker: function(marker)
    {
        this._map.removeOverlay(marker);
        Array.remove(markerList, marker);
    },

    getMarker: function(id)
    {
        for (var i = 0; i < markerList.length; i++)
        {
            if (markerList[i].id == id)
            {
                return markerList[i];
            }
        }
        return null;
    },

    get_Latitude : function()
    {
        return this._latitude;
    },

    set_Latitude : function(value)
    {
        this._latitude = value;
    },
    
    get_Longitude : function()
    {
        return this._longitude;
    },

    set_Longitude : function(value)
    {
        this._longitude = value;
    },
    
    get_Zoom : function()
    {
        return this._zoom;
    },

    set_Zoom : function(value)
    {
        this._zoom = value;
    }   
}

Appian.MapBehavior.registerClass('Appian.MapBehavior', Sys.UI.Behavior);

/* Street Map Behavior
----------------------------------------------- */

var searchPointList = [];
var searchReviewList = [];
var searchResultList = [];

Appian.StreetMapBehavior = function(element)
{
    Appian.StreetMapBehavior.initializeBase(this, [element]);

    this._streetData = _streetData;
    this._featureData = null;
    this._regionID = _regionID;
    
    this._clickHandler = null;
    this._searchPointCompletedHandler = null;
    this._searchReviewsCompletedHandler = null;
    this._searchFailedHandler = null;
    this._resetOverlayHandler = null;
    this._updatePinCushionCompletedHandler = null;
    this._updatePinCushionFailedHandler = null;

    this._addressDetailsSummaryFormat = '<div class="searchitem searchitemsummary"><div class="c-h"><h4><a href="{1}">{0}</a></h4><a href="{1}" class="visit">Visit this {2}</a></div></div>';
    this._searchRating = new Appian.AddressRating();
    this._streetviewClient = null;
}

Appian.StreetMapBehavior.prototype = {

    initialize : function()
    {
        Appian.StreetMapBehavior.callBaseMethod(this, 'initialize');

        // Create delegates
        this._clickHandler = Function.createDelegate(this, this.searchPoint);
        this._searchPointCompletedHandler = Function.createDelegate(this, this._onSearchPointCompleted);
        this._searchReviewsCompletedHandler = Function.createDelegate(this, this._onSearchReviewsCompleted);
        this._searchFailedHandler = Function.createDelegate(this, this._onSearchFailed);
        this._resetOverlayHandler = Function.createDelegate(this, this.findReviews);
        this._updatePinCushionCompletedHandler = Function.createDelegate(this, this._onUpdatePinCushionCompleted);
        this._updatePinCushionFailedHandler = Function.createDelegate(this, this._onSearchFailed);
    },

    loadMap: function()
    {
        Appian.StreetMapBehavior.callBaseMethod(this, 'loadMap');

        // Attach events
        var clickListener = GEvent.addListener(this._map, 'click', this._clickHandler);
        this._map.ClickListener_ = clickListener;
        
        GEvent.addListener(this._map, 'dragend', this._resetOverlayHandler);
        
        this._loadSearchMessage();
    },

    resetOverlays: function()
    {
        Appian.StreetMapBehavior.callBaseMethod(this, 'resetOverlays');

        // Search markers
        this.display_ResultMarkers();
        
        // Street marker
        if (this._streetData)
        {
            this.add_StreetMarker(this._streetData);
        }

        // Feature marker
        if (this._featureData)
        {
            this.add_FeatureMarker(this._featureData);
        }

        // Search markers
        this.display_PointMarkers();
                
        this.findReviews();
    },
   
    zoomOut: function()
    {
        Appian.StreetMapBehavior.callBaseMethod(this, 'zoomOut');
        
        this.findReviews();
    },

    setZoom: function(value)
    {
        if (this._map.getZoom() > value)
        {
            this.findReviews();
        }
        
        Appian.StreetMapBehavior.callBaseMethod(this, 'setZoom', [value]);
    },

    searchPoint: function(overlay, point)
    {
        if (point)
        {
            var marker = new GMarker(point);
            
            this._map.addOverlay(marker);

            marker.openInfoWindowHtml('Searching...');

            // Search street
            Appian.Services.UIService.SearchAddressByMap(point.lat(),
                point.lng(),
                this._searchPointCompletedHandler,
                this._searchFailedHandler, 
                marker);
        }
    },

    _onSearchPointCompleted: function(result, marker)
    {
        var data = eval(result);

        this._map.closeInfoWindow();
        
        this.remove_Marker(marker);

        if (!data)
        {
            // TODO: Show search failed marker.
            return;
        }

        var newMarker = this.add_PointMarker(data);
        if (newMarker)
        {
            // Open new marker
            this.showMarkerData(newMarker, data);
        }
    },

    _onSearchFailed : function(result)
    {
        //alert(result.get_message());
    },

    updateRating: function(rating, value)
    {
        this._searchRating[rating] = value;
    },

    showSearchMessage : function()
    {
        this._setSearchMessage('block');
    },
    
    hideSearchMessage : function()
    {
        this._setSearchMessage('none');
    },
    
    _loadSearchMessage : function()
    {
        message = document.createElement('div');
        message.className = 'searching';
        message.innerHTML = __spinner + 'Searching...';
        message.style.display = 'none';
        this._map.getContainer().appendChild(message);
    },
    
    _setSearchMessage : function(value)
    {
        var message = getElementsByClassName('searching', 'div', this._map.getContainer());
        if (message.length > 0)
        {
            message[0].style.display = value;
        }
    },

    findReviews: function()
    { 
        var point = this._map.getCenter();

        // TODO: Show "loading reviews..."
        this.showSearchMessage();

        // Search reviews
        Appian.Services.UIService.SearchPinsOnMap(point.lat(),
            point.lng(),
            this.getMapRadius(),
            this._regionID,
            this._searchRating.NeighbourlySpirit,
            this._searchRating.EatingOut,
            this._searchRating.Nightlife,
            this._searchRating.RetailTherapy,
            this._searchRating.Fitness,
            this._searchRating.MobilePhoneReception,
            this._searchRating.InternetAccess,
            this._searchRating.PayTVAccess,
            this._searchRating.PeaceAndQuiet,
            this._searchRating.LackOfTraffic,
            this._searchRating.SafeAndSound,
            this._searchRating.CleanAndGreen,
            this._searchRating.PestFree,
            this._searchRating.CostOfLiving,
            this._searchRating.ResaleOrRentalValue,
            this._searchRating.PublicTransport,
            this._searchRating.MedicalFacilities,
            this._searchRating.Schools,
            this._searchRating.Childcare,
            this._searchRating.LocalGovernment,
            this._searchRating.PowerWaterGas,
            this._searchRating.ParksAndRecreational,
            this._searchReviewsCompletedHandler,
            this._searchFailedHandler);
    },

    _onSearchReviewsCompleted : function(result)
    {        
        // TODO: Hide "loading reviews..."
        this.hideSearchMessage();
        
        // Clear existing reviews
        this.clear_ReviewMarkers();
        
        if (result != null)
        {
            for (var i = 0; i < result.length; i++)
            {
                this.add_ReviewMarker(result[i]);
            }
        }
    },

    dispose : function()
    {
        if (this._clickHandler)
        {
            this._clickHandler = null;
        }

        if (this._searchPointCompletedHandler)
        {
            this._searchPointCompletedHandler = null;
        }
        
        if (this._searchReviewsCompletedHandler)
        {
            this._searchReviewsCompletedHandler = null;
        }

        if (this._searchFailedHandler)
        {
            this._searchFailedHandler = null;        
        }

        if (this._resetOverlayHandler)
        {
            this._resetOverlayHandler = null;        
        }

        Appian.StreetMapBehavior.callBaseMethod(this, 'dispose');
    },

    add_FeatureMarker: function()
    {
        if (this._featureData)
        {
            this.remove_FeatureMarker();
        }
        
        var newMarker = this.addMarker(this._featureData, 'feature');
    },
    
    remove_FeatureMarker: function()
    {
        var marker = this.getMarker(this._featureData.Id);

        this.remove_Marker(marker);
    },

    set_StreetMarker: function(data)
    {
        if (this._streetData)
        {
            if (this._streetData.Id == data.Id)
            {
                return;
            }
            
            // Remove existing street
            this.remove_StreetMarker();
        }

        this.add_StreetMarker(data);
    },

    add_StreetMarker: function(data)
    {
        // Remove existing review
        this.remove_ReviewMarker(data.Id);

        // Remove existing point
        this.remove_PointMarker(data.Id);

        //this.set_StreetData(data);
        var newMarker = this.addMarker(this._streetData, 'street');
        
        return newMarker;
    },

    remove_StreetMarker: function()
    {
        var marker = this.getMarker(this._streetData.Id);

        this.remove_Marker(marker);

        // Replace existing street with a review
        //if (this._streetData.RC > 0)
        //{   
            this.add_ReviewMarker(this._streetData);
        //}
    },

    add_PointMarker: function(data)
    {
        // Check existing street
        if (this._streetData)
        {
            if (this._streetData.Id == data.Id)
            {
                // Show street
                this.showMarkerData(this.getMarker(this._streetData.Id), data);
                return;
            }
        }

        // Check existing review
        var existingReview = Array.getItemById(searchReviewList, data.Id);
        if (existingReview)
        {
            // Show review
            this.showMarkerData(this.getMarker(existingReview.Id), existingReview);
            return;
        }

        // Check existing point
        var existingPoint = Array.getItemById(searchPointList, data.Id);
        if (existingPoint)
        {
            // Show point
            this.showMarkerData(this.getMarker(existingPoint.Id), existingPoint);
            return;
        }

        Array.add(searchPointList, data);
        var newMarker = this.addMarker(data, 'point');

        return newMarker;
    },

    display_PointMarkers: function()
    {
        for (var i = 0; i < searchPointList.length; i++)
        {
            this.addMarker(searchPointList[i], 'point');
        }
    },

    remove_PointMarker: function(id)
    {
        this.remove_ListMarker(searchPointList, id);
    },
    
    display_ResultMarkers: function()
    {
        for (var i = 0; i < searchResultList.length; i++)
        {
            this.addMarker(searchResultList[i], 'result');
        }
    },

    add_ResultData: function(list)
    {
        var existingResult;
        for (var i = 0; i < list.length; i++)
        {
            existingResult = Array.getItemById(searchResultList, list[i].Id);
            if (!existingResult)
            {
                Array.add(searchResultList, list[i]);
            }
        }
    },

    clear_ResultMarkers: function()
    {
    
    },

    add_ReviewMarker: function(data)
    {
        // Check existing street
        if (this._streetData)
        {
            if (this._streetData.Id == data.Id)
            {
                return;
            }
        }

        // Check existing review
        var existingReview = Array.getItemById(searchReviewList, data.Id);
        if (existingReview)
        {
            return;
        }
        
        // Remove existing point
        this.remove_PointMarker(data.Id);

        Array.add(searchReviewList, data);
        var newMarker = this.addMarker(data, 'review');

        return newMarker;
    },
    
    clear_ReviewMarkers: function()
    {
        if (searchReviewList)
        {
            while (searchReviewList.length > 0)
            {
                this.remove_ReviewMarker(searchReviewList[0].Id);
            }
        }
    },
    
    remove_ReviewMarker: function(id)
    {
        this.remove_ListMarker(searchReviewList, id);
    },

    remove_ListMarker: function(list, id)
    {
        if (list.length == 0) return;
 
        var item = Array.getItemById(list, id);
        if (item)
        {
            var marker = this.getMarker(item.Id);
            if (marker != null)
            {
                this.remove_Marker(marker);
            }
            Array.remove(list, item);
        }
    },

    addMarker : function(data, type)
    {
        var icon;

        switch (type) 
        {
            case 'street':
                icon = data.T == 's' ? createStreetIcon(data.RR) : createCityIcon(data.RR);
                break;
            case 'point':
                icon = createPointIcon();
                break;
            case 'review': 
            case 'result':
                icon = data.T == 's' ? createReviewIcon(data.RR) : createCityIcon(data.RR);
                break;
            case 'feature':
                icon = data.T == 's' ? createStreetIcon(0) : createCityIcon(0);
                break;
        }
        
        var point = new GLatLng(data.Lat, data.Lng);
        var marker = new GMarker(point, { id: data.Id, title: data.FA, icon: icon, draggable: false });

        this.add_Marker(marker);

        var me = this;
        GEvent.addListener(marker, 'click', function()
        {
            var data = me.getMarkerData(marker, type);
            if (data)
            {
                me.showMarkerData(marker, data);
            }
        });
        
        GEvent.addListener(marker, 'dragstart', function() 
        {
            me._map.closeInfoWindow();
        });

        GEvent.addListener(marker, 'dragend', function()
        {
            var point = me._map.getCenter();
            
            var data = me.getMarkerData(marker, type);
            if (data)
            {
                Appian.Services.UIService.UpdatePinCushion(point.lat(),
                    point.lng(),
                    data.Id,
                    me._updatePinCushionCompletedHandler,
                    me._updatePinCushionFailedHandler, 
                    marker);
            }
        });

        return marker;
    },

    _onUpdatePinCushionCompleted: function(result, marker)
    {
        if (result == '')
        {
            return;
        }

        var data = eval('(' + result + ')');

        var point = new GLatLng(data.Latitude, data.Longitude);

        marker.setPoint(point);
    },

    getMarkerData: function(marker, type)
    {
        var data;
        
        switch (type) 
        {
            case 'street':
                data = this._streetData;
                break;
            case 'point':
                data = Array.getItemById(searchPointList, marker.id);
                break;
            case 'review':
                data = Array.getItemById(searchReviewList, marker.id);
                break;
            case 'result':
                data = Array.getItemById(searchResultList, marker.id);
                break;
        }
        
        return data;
    },

    showMarkerData: function(marker, data)
    {
    },

    updateStreetData: function(data)
    {
        if (this._streetData.Id == data.Id)
        {
            return;
        }

        this.set_StreetMarker(data);
    
        this.resetView();
    },

    get_StreetData : function()
    {
        return this._streetData;
    },

    set_StreetData : function(value)
    {
        this._streetData = value;
        
        if (value)
        {
            this._latitude = value.Lat;
            this._longitude = value.Lng;
            this._zoom = 16;
        }
        
        // Global
        _streetData = value;
    },
    
    get_FeatureData : function()
    {
        return this._featureData;
    },

    set_FeatureData : function(value)
    {
        this._featureData = value.FeatureData;

        this.add_FeatureMarker();
    },

    get_RegionID : function()
    {
        return this._regionID;
    },

    set_RegionID : function(value)
    {
        this._regionID = value;
    }
}

Appian.StreetMapBehavior.registerClass('Appian.StreetMapBehavior', Appian.MapBehavior);

/* Facebook Map Behavior
----------------------------------------------- */


Appian.FacebookMapBehavior = function(element)
{
    Appian.FacebookMapBehavior.initializeBase(this, [element]);
}

Appian.FacebookMapBehavior.prototype = {

    initialize : function()
    {
        Appian.FacebookMapBehavior.callBaseMethod(this, 'initialize');

        Sys.Application.add_load(Function.createDelegate(this, this.loadMap));
    },

    loadMap: function()
    {
        if (!this._map)
        {
            Appian.FacebookMapBehavior.callBaseMethod(this, 'loadMap');
        }

        // Load data
        this.updateMap();
    },

    showMarkerData: function(marker, data)
    {
        if (!marker) return;

        var content = String.format(this._addressDetailsSummaryFormat, 
            data.FA, 
            String.format(__fbAddressPathFormat, data.Id),
            data.T != '' ? (data.T == 's' ? 'street' : 'city') : 'place');

        marker.openInfoWindowHtml(content);
    }
}

Appian.FacebookMapBehavior.registerClass('Appian.FacebookMapBehavior', Appian.StreetMapBehavior);

/* Small Map Behavior
----------------------------------------------- */

Appian.SmallMapBehavior = function(element)
{
    Appian.SmallMapBehavior.initializeBase(this, [element]);
}

Appian.SmallMapBehavior.prototype = {

    initialize : function()
    {
        Appian.SmallMapBehavior.callBaseMethod(this, 'initialize');
        
        // Attach events
        Sys.Application.add_load(Function.createDelegate(this, this.loadMap));
    },

    loadMap: function()
    {
        if (!this._map)
        {
            Appian.SmallMapBehavior.callBaseMethod(this, 'loadMap');
            
            var zoomControl = new SmallMapZoomControl();
            zoomControl.set_MapBehaviour(this);
            this._map.addControl(zoomControl);
            this._map.addControl(new MapOpenControl());

            var corner = document.createElement('div');
            corner.className = 'mapCorner';
            this._map.getContainer().appendChild(corner);

            this._timer = window.setInterval(Function.createDelegate(this, this._timerCallback), 1000);
        }

        // Load data
        this.updateMap();
    },

    _timerCallback : function()
    {
        // Zoom out if too close.
        if(this._map.getContainer().getElementsByTagName('p').length > 2)
        {
            this._map.zoomOut(false, true);
        }
    },

    showMarkerData: function(marker, data)
    {
        if (!marker) return;

        var content = String.format(this._addressDetailsSummaryFormat, 
            data.FA, 
            data.Url,
            data.T != '' ? (data.T == 's' ? 'street' : 'city') : 'place');

        marker.openInfoWindowHtml(content);
    }
}

Appian.SmallMapBehavior.registerClass('Appian.SmallMapBehavior', Appian.StreetMapBehavior);

/* Medium Map Behavior
----------------------------------------------- */

Appian.MediumMapBehavior = function(element)
{
    Appian.MediumMapBehavior.initializeBase(this, [element]);
}

Appian.MediumMapBehavior.prototype = {

    initialize : function()
    {
        Appian.MediumMapBehavior.callBaseMethod(this, 'initialize');
    },

    loadMap: function()
    {
        if (!this._map)
        {
            Appian.MediumMapBehavior.callBaseMethod(this, 'loadMap');

            // Only display first time
            //if (!ASPCode.net.CookieManager.getCookie('MapTipControl'))
            //{
                this._map.addControl(new SmallMapTipControl());
            //}
        }

        // Load data
        this.updateMap();
    }
}

Appian.MediumMapBehavior.registerClass('Appian.MediumMapBehavior', Appian.SmallMapBehavior);

/* Large Map Behavior
----------------------------------------------- */

Appian.LargeMapBehavior = function(element)
{
    Appian.LargeMapBehavior.initializeBase(this, [element]);

    this._showStreetview = true;
    this._mapStreetViewControl = null;
    
    this._getLocationItemCompletedHandler = null;
    this._getLocationItemFailedHandler = null;
    
    this._panoOpen = false;
    this._panoZoom = false;
    this._panoPOV = null;
    this._panoEmptyMessage = '<h3>Street View</h3>Drag me onto a blue outlined street.';
    
    this._infoWindowId = 'location_window_large';
    this._infoWindowContentFormat = '<div class="info_location"><div id="infowindow_pano"><span class="loading">Loading streetview...</span></div><div id="infowindow_desc"></div></div>';
    this._infoWindowContentId = 'location_window_large_contents';
    this._panoContentId = 'infowindow_pano';
    this._panoExpandoId = 'location_window_large_full';
    this._descContentId = 'infowindow_desc';
}

Appian.LargeMapBehavior.prototype = {

    initialize : function()
    {
        Appian.LargeMapBehavior.callBaseMethod(this, 'initialize');

        this._getLocationItemCompletedHandler = Function.createDelegate(this, this._onGetLocationItemCompleted);
        this._getLocationItemFailedHandler = Function.createDelegate(this, this._onSearchFailed);
    },

    loadMap: function()
    {
        if (!this._map)
        {
            Appian.LargeMapBehavior.callBaseMethod(this, 'loadMap');

            var zoomControl = new MapZoomControl();
            zoomControl.set_MapBehaviour(this);
            this._map.addControl(zoomControl);

            this._mapStreetViewControl = new MapStreetViewControl();
            this._mapStreetViewControl.set_MapBehaviour(this);
            this._map.addControl(this._mapStreetViewControl);

		    this._map.addControl(new MapTypeControl());	
		    this._map.addControl(new MapCloseControl());	
		    this._map.addControl(new MapTipControl());
		    
            this._map.enableScrollWheelZoom();
            
            // StreetView (US Only)
            if (this._regionID != 'US')
            {
                this._showStreetview = false;
            }
        }

        // Load data
        this.updateMap();
    },

    updateMap: function()
    {
        this._map.closeExtInfoWindow();
        
        Appian.LargeMapBehavior.callBaseMethod(this, 'updateMap');
        
        if (this._showStreetview)
        {
            this.loadStreetview();
	    }
    },

    toggleControls: function(state)
    {
        getElementsByClassName('MapZoomControl', null, this._map.getContainer())[0].style.display = state ? 'block' : 'none';
        getElementsByClassName('MapTypeControl', null, this._map.getContainer())[0].style.display = state ? 'block' : 'none';
        getElementsByClassName('MapCloseControl', null, this._map.getContainer())[0].style.display = state ? 'block' : 'none';
        getElementsByClassName('MapTipControl', null, this._map.getContainer())[0].style.display = state ? 'block' : 'none';
        getElementsByClassName('MapStreetViewControl', null, this._map.getContainer())[0].style.display = state ? 'block' : 'none';
        getElementsByClassName('infoElement', null, null)[0].style.display = state ? 'block' : 'none';
    },

    openDefaultItem: function()
    {
        if (this._streetData)
        {
            this.showMarkerData(this.getMarker(this._streetData.Id), this._streetData);
        }
    },

    searchPoint: function(overlay, point)
    {
        if (point)
        {
            var marker = new GMarker(point);
            
            this._map.addOverlay(marker);

            marker.openExtInfoWindow(
                this._map,
                this._infoWindowId,
                this._infoWindowContentFormat,
                {beakOffset: 0, fullscreen: true}
            );
        
            this._setLocationContent('<span class="loading">Searching location...</span>');
        
            this._searchLocationItem(marker.getLatLng());
        
            if (this._showStreetview)
            {
                this._openPanorama(marker.getLatLng());
            }
        }
    },

    showMarkerData: function(marker, data)
    {
        if (!marker) return;

        marker.openExtInfoWindow(
            this._map,
            this._infoWindowId,
            this._infoWindowContentFormat,
            {beakOffset: 0, fullscreen: true}
        );

        this._getLocationItem(data.Id);

        if (this._showStreetview)
        {
            var point = new GLatLng(data.Lat, data.Lng);
            this._openPanorama(point);
        }
    },

    _searchLocationItem : function(point)
    {       
        var me = this;
        Appian.Services.UIService.SearchLocationItem(point.lat(),
            point.lng(),
            me._getLocationItemCompletedHandler,
            me._getLocationItemFailedHandler);
    },

    _getLocationItem : function(id)
    {
        this._setLocationContent('<span class="loading">Loading description...</span>');
        
        var me = this;
        Appian.Services.UIService.GetLocationItem(id,
            me._getLocationItemCompletedHandler,
            me._getLocationItemFailedHandler);
    },

    _onGetLocationItemCompleted : function(result)
    {
        if (result == '' && !this._panoOpen)
        {
            this._map.closeExtInfoWindow();
        }
        
        this._setLocationContent(result);
    },  

    _setLocationContent : function(value)
    {
        var element = $get(this._descContentId);
        if (element)
        {
            element.innerHTML = value;

            if (!this._panoZoom) this._map.getExtInfoWindow().resize();
        }
    },

    loadStreetview: function()
    {
        this._streetviewClient = new GStreetviewClient();
        
        var latlng = this._map.getCenter();
        this._lastMarkerLocation = latlng;
        
        // Marker.
        this._loadStreetViewMarker(latlng);
                
        // Overlay.
        //this._streetviewOverlay = new GStreetviewOverlay();
        //this._map.addOverlay(this._streetviewOverlay);
        this._mapStreetViewControl.set_Visible(true);
        this._mapStreetViewControl.set_Active(true);
                
        GEvent.addListener(this._map, 'extinfowindowclose', Function.createDelegate(this, function()
        {
            if (this._showStreetview)
            {
                if (this._panoZoom) this._map.panTo(this._map.getExtInfoWindow().marker_.getPoint());
                this._closePanorama(false);
            }
        }));
    },

    _loadStreetViewMarker: function(latlng)
    {
        this._streetviewMarker = new GMarker(latlng, {icon: createStreetviewIcon(), draggable: true});
        this._map.addOverlay(this._streetviewMarker);

        GEvent.addListener(this._streetviewMarker, 'dragend', Function.createDelegate(this, this._onStreetviewDragEnd));
    },

    removeStreetview: function()
    {
        //this._map.removeOverlay(this._streetviewOverlay);
        this._mapStreetViewControl.set_Active(false);
        this._closePanorama();
    },

    toggleStreetView: function()
    {
        this.setStreetView(!this._showStreetview);
    },

    setStreetView: function(value)
    {
        this._showStreetview = value;
        value ? this.loadStreetview() : this.removeStreetview();
    },

    _onStreetviewDragEnd: function()
    {
        var latlng = this._streetviewMarker.getLatLng();
        if (this._streetviewPanorama) 
        {
            this._streetviewClient.getNearestPanorama(latlng, Function.createDelegate(this, this._onResponse));
            this._searchLocationItem(latlng);
        }
    },
    
    _openPanorama: function(latlng)
    {
        this._streetviewMarker.setPoint(latlng);

        var panoElement = $get(this._panoContentId);
        panoElement.style.display = 'block';

        this._map.getExtInfoWindow().set_FullEnabled(true);
        this._map.getExtInfoWindow().resize();

        this._streetviewPanorama = new GStreetviewPanorama(panoElement);

        GEvent.addListener(this._streetviewPanorama, 'initialized', Function.createDelegate(this, this._onNewLocation));
        GEvent.addListener(this._streetviewPanorama, 'yawchanged', Function.createDelegate(this, this._onYawChange)); 
        GEvent.addListener(this._streetviewPanorama, 'error', Function.createDelegate(this, this._onPanoramaError));
        $addHandler($get(this._panoExpandoId), 'click', Function.createDelegate(this, this._expandPanoramaBubble));

        this._streetviewPanorama.setLocationAndPOV(latlng, this._panoPOV);
        this._streetviewPanorama.setPOV(this._panoPOV);

        this._panoOpen = true;
        this._panoZoom = false;
        this._panoMove = false;
    },

    _expandPanoramaBubble: function(e)
    {
        var w = this._panoZoom ? 500 : Math.min(this._map.getSize().width - 100, 1500);
        var h = this._panoZoom ? 262 : Math.min(this._map.getSize().height - 100, 1500);
        
        $get(this._panoContentId).style.width = w + 'px';
        $get(this._panoContentId).style.height = h + 'px';

        Sys.UI.DomElement.toggleCssClass($get(this._infoWindowId), 'full_open');

        this._map.getExtInfoWindow().contentWidth = w;
        $get(this._infoWindowContentId).style.width = w + 'px';
        
        if (this._panoZoom)
        {
            h += Sys.UI.DomElement.getBounds($get(this._descContentId)).height;
            this._searchLocationItem(this._streetviewMarker.getPoint());
        }
        
        $get(this._infoWindowContentId).style.height = h + 'px';

        this._map.getExtInfoWindow().redraw_(true);
        
        this._streetviewPanorama.checkResize();
        
        var d = Sys.UI.DomElement.getBounds($get(this._infoWindowContentId));
        var point = this._map.fromContainerPixelToLatLng(new GPoint(d.x + parseInt(d.width / 2), (d.y - 82) + parseInt(d.height / 2)));
        this._panoZoom ? this._map.panTo(point) : this._map.setCenter(point);

        this.toggleControls(this._panoZoom ? true : false);
        
        this._panoZoom = !this._panoZoom;
       
        stopEvent(e);
    },

    _closePanorama: function(showMessage)
    {
        this.toggleControls(true);
        
        this._panoPOV = null;    
        this._panoOpen = false;
        
        var panoElement = $get(this._panoContentId);
        if (panoElement)
        {
            panoElement.style.display = 'none';
            this._map.getExtInfoWindow().resize();
        }

        this._map.getExtInfoWindow().set_FullEnabled(false);
    },

    _onPanoramaError: function(errorCode)
    {
        if (errorCode == 603)
        {
            alert('Error: Flash doesn’t appear to be supported by your browser');
            return;
        }
        
        this._closePanorama(true);
    },

    _onNewLocation: function(location)
    {      
        if (!this._panoMove)
        {
            var markerHeight = this._map.getExtInfoWindow().marker_.getIcon().iconSize.height;
            var oldPixelCenter = this._map.fromLatLngToContainerPixel(this._map.getCenter()); 
            var newPixelCenter = this._map.fromContainerPixelToLatLng(new GPoint(oldPixelCenter.x, oldPixelCenter.y + markerHeight));
            this._map.setCenter(newPixelCenter);
            this._panoMove = true;
        }

        this._map.getExtInfoWindow().marker_ = this._streetviewMarker;

        var oldLoc = this._streetviewMarker.getPoint();

        this._streetviewMarker.setLatLng(location.latlng);
        this._map.getExtInfoWindow().reposition();
        
        var newLoc = this._streetviewMarker.getPoint();

        this._map.setCenter(new GLatLng(this._map.getCenter().y - (oldLoc.y - newLoc.y), this._map.getCenter().x - (oldLoc.x - newLoc.x)));
        
        if (!this._panoZoom)
        {
            this._searchLocationItem(location.latlng);
        }
    },
    
    _onYawChange: function(newYaw) 
    {
        if (newYaw < 0) 
        {
            newYaw += 360;
        }
        this._panoPOV = {yaw: newYaw};
    },
    
    _onResponse: function(response) 
    {
        if (response.code != 200) 
        {
            this._streetviewMarker.setLatLng(this._lastMarkerLocation);
            this._closePanorama(true);
        } 
        else 
        {
            var latlng = response.location.latlng;
            this._streetviewMarker.setLatLng(latlng);
            this._lastMarkerLocation = latlng;
            this._openPanorama(latlng);
        }
    }
}

Appian.LargeMapBehavior.registerClass('Appian.LargeMapBehavior', Appian.StreetMapBehavior);

/* Search Map Behavior
----------------------------------------------- */

Appian.SearchMapBehavior = function(element)
{
    Appian.SearchMapBehavior.initializeBase(this, [element]);
}

Appian.SearchMapBehavior.prototype = {

    initialize : function()
    {
        Appian.SearchMapBehavior.callBaseMethod(this, 'initialize');
    },

    loadMap: function()
    {
        if (!this._map)
        {
            Appian.SearchMapBehavior.callBaseMethod(this, 'loadMap');
        }

        // Load data
        this.updateMap();
    }
}

Appian.SearchMapBehavior.registerClass('Appian.SearchMapBehavior', Appian.SmallMapBehavior);

/***********************************/

function createInfoPanel(element)
{
    // Search Box
    //element.innerHTML = '<div id="mapsearch" class="infoItem"><h3>Search</h3><input type="text" id="mapsearchtext" /><input type="button" value="testme" onclick="testme()" /></div>';

    // Panel
    var refine = document.createElement('div');
    refine.id = 'refinePanel';
    refine.className = 'infoItem';
    element.appendChild(refine);
    
    // Refine Header
    var refineHeader = document.createElement('div');
    refineHeader.id = 'refineHeader';
    refineHeader.innerHTML = '<h3>Refine Your Search</h3>';
    //refineHeader.className = 'c-h';
    refine.appendChild(refineHeader);

    // Refine Body
    var refineBody = document.createElement('div');
    refineBody.id = 'refineBody';
    //refineBody.className = 'c-b';
    refine.appendChild(refineBody);
    
    
    // StreetVIBE
    
    var refineHeader1 = document.createElement('div');
    refineHeader1.id = 'refineHeader1';
    refineHeader1.className = 'refineHeader';
    refineHeader1.innerHTML = '<h4>StreetVIBE</h4>';
    refineBody.appendChild(refineHeader1);
    
    var refineBody1 = document.createElement('div');
    refineBody1.id = 'refineBody1';
    refineBody1.className = 'refineBody';
    refineBody.appendChild(refineBody1);
    
    createSlider(refineBody1, 'searchslider1', 'Neighborly Spirit', function(sender, e)
    {
        updateReviewRating(sender, 'NeighbourlySpirit');
    });
    
    createSlider(refineBody1, 'searchslider2', 'Eating Out', function(sender, e)
    {
        updateReviewRating(sender, 'EatingOut');
    });

    createSlider(refineBody1, 'searchslider3', 'Nightlife', function(sender, e)
    {
        updateReviewRating(sender, 'Nightlife');
    });

    createSlider(refineBody1, 'searchslider4', 'Retail Therapy', function(sender, e)
    {
        updateReviewRating(sender, 'RetailTherapy');
    });

    createSlider(refineBody1, 'searchslider5', 'Health & Fitness', function(sender, e)
    {
        updateReviewRating(sender, 'Fitness');
    });
    
    // StreetWIRED
    
    var refineHeader2 = document.createElement('div');
    refineHeader2.id = 'refineHeader2';
    refineHeader2.className = 'refineHeader';
    refineHeader2.innerHTML = '<h4>StreetWIRED</h4>';
    refineBody.appendChild(refineHeader2);
    
    var refineBody2 = document.createElement('div');
    refineBody2.id = 'refineBody2';
    refineBody2.className = 'refineBody';
    refineBody.appendChild(refineBody2);
    
    createSlider(refineBody2, 'searchslider6', 'Cell/Mobile Reception', function(sender, e)
    {
        updateReviewRating(sender, 'MobilePhoneReception');
    });
    
    createSlider(refineBody2, 'searchslider7', 'Internet Access', function(sender, e)
    {
        updateReviewRating(sender, 'InternetAccess');
    });
    
    createSlider(refineBody2, 'searchslider8', 'Pay TV Access', function(sender, e)
    {
        updateReviewRating(sender, 'PayTVAccess');
    });
    
    // StreetHEALTH
    
    var refineHeader3 = document.createElement('div');
    refineHeader3.id = 'refineHeader3';
    refineHeader3.className = 'refineHeader';
    refineHeader3.innerHTML = '<h4>StreetHEALTH</h4>';
    refineBody.appendChild(refineHeader3);
    
    var refineBody3 = document.createElement('div');
    refineBody3.id = 'refineBody3';
    refineBody3.className = 'refineBody';
    refineBody.appendChild(refineBody3);
    
    createSlider(refineBody3, 'searchslider9', 'Peace & Quiet', function(sender, e)
    {
        updateReviewRating(sender, 'PeaceAndQuiet');
    });
    
    createSlider(refineBody3, 'searchslider10', 'Traffic', function(sender, e)
    {
        updateReviewRating(sender, 'LackOfTraffic');
    });
    
    createSlider(refineBody3, 'searchslider11', 'Safe & Sound', function(sender, e)
    {
        updateReviewRating(sender, 'SafeAndSound');
    });
    
    createSlider(refineBody3, 'searchslider12', 'Clean & Green', function(sender, e)
    {
        updateReviewRating(sender, 'CleanAndGreen');
    });
    
    createSlider(refineBody3, 'searchslider13', 'Pest Free', function(sender, e)
    {
        updateReviewRating(sender, 'PestFree');
    });
    
    // StreetVALUE
    
    var refineHeader4 = document.createElement('div');
    refineHeader4.id = 'refineHeader4';
    refineHeader4.className = 'refineHeader';
    refineHeader4.innerHTML = '<h4>StreetVALUE</h4>';
    refineBody.appendChild(refineHeader4);
    
    var refineBody4 = document.createElement('div');
    refineBody4.id = 'refineBody4';
    refineBody4.className = 'refineBody';
    refineBody.appendChild(refineBody4);
    
    createSlider(refineBody4, 'searchslider14', 'Cost Of Living', function(sender, e)
    {
        updateReviewRating(sender, 'CostOfLiving');
    });
    
    createSlider(refineBody4, 'searchslider15', 'Resale Or Rental Value', function(sender, e)
    {
        updateReviewRating(sender, 'ResaleOrRentalValue');
    });

    // StreetESSENTIALS
    
    var refineHeader5 = document.createElement('div');
    refineHeader5.id = 'refineHeader3';
    refineHeader5.className = 'refineHeader';
    refineHeader5.innerHTML = '<h4>StreetESSENTIALS</h4>';
    refineBody.appendChild(refineHeader5);
    
    var refineBody5 = document.createElement('div');
    refineBody5.id = 'refineBody4';
    refineBody5.className = 'refineBody';
    refineBody.appendChild(refineBody5);
    
    createSlider(refineBody5, 'searchslider16', 'Public Transport', function(sender, e)
    {
        updateReviewRating(sender, 'PublicTransport');
    });
    
    createSlider(refineBody5, 'searchslider17', 'Medical Facilities', function(sender, e)
    {
        updateReviewRating(sender, 'MedicalFacilities');
    });
    
    createSlider(refineBody5, 'searchslider18', 'Schools', function(sender, e)
    {
        updateReviewRating(sender, 'Schools');
    });
    
    createSlider(refineBody5, 'searchslider19', 'Child care', function(sender, e)
    {
        updateReviewRating(sender, 'Childcare');
    });
    
    createSlider(refineBody5, 'searchslider20', 'Local Government', function(sender, e)
    {
        updateReviewRating(sender, 'LocalGovernment');
    });
    
    createSlider(refineBody5, 'searchslider21', 'Power Water Gas', function(sender, e)
    {
        updateReviewRating(sender, 'PowerWaterGas');
    });
    
    createSlider(refineBody5, 'searchslider22', 'Parks & Recreation', function(sender, e)
    {
        updateReviewRating(sender, 'ParksAndRecreational');
    });


    // Accordion Behavior
    $create(AjaxControlToolkit.AccordionBehavior, {'id':'refineBehavior','HeaderCssClass':'refineHeader'}, null, null, refineBody);
}

function createSlider(container, id, title, action)
{
    // Label
    var label = document.createElement('label');
    label.innerHTML = title;// + ':';
    container.appendChild(label);
    
    // Slider
    var textbox = document.createElement('input');
    textbox.type = 'text';
    textbox.id = id;
    textbox.style.display = 'none';
    container.appendChild(textbox);

    var behaviour = $create(AjaxControlToolkit.SliderBehavior, {
        'EnableHandleAnimation' : true,
        'id': id + 'Behaviour',
        'RailCssClass': 'sliderrail',
        'HandleCssClass': 'sliderhandle',
        'HandleImageUrl':'/image/slider_handle.gif',
        'Orientation': 0,
        'Steps': 5,
        'Minimum': 0,
        'Maximum': 4,
        'Value': 0,
        'RaiseChangeOnlyOnMouseUp': true}, {valueChanged : action}, null, textbox);
}

function updateReviewRating(slider, rating)
{
    _mapModal._mapBehavior.updateRating(rating, slider.get_Value());
    _mapModal._mapBehavior.findReviews();

    //var target = $get('refinePanel');
    //AjaxControlToolkit.Animation.OpacityAction.play(target, 1, 30, 0.5);
}

/* Map Modal Behavior
----------------------------------------------- */

var _mapModal = null;

Appian.MapModal = function(element) 
{
    Appian.MapModal.initializeBase(this, [element]);

    this._mapBehavior = null;
    
    this._backgroundElement = null;
    this._modalElement = null;
    this._infoElement = null;
    this._mapElement = null;
    this._headerElement = null;
    this._shadowElement = null;
    
    this._scrollHandler = null;
    this._resizeHandler = null;
    
    this._marginWidth = 0;//50;
    this._marginHeight = 0;//50;
    this._isOpen = false;
    this._ieFix = null;
    
    this._searchBehaviour = null;
    
    this._mapOptions = null;
}

Appian.MapModal.prototype = {

    initialize : function()
    {
        Appian.MapModal.callBaseMethod(this, 'initialize');

        var e = this.get_element();

        // Modal background
        this._backgroundElement = document.createElement('div');
        this._backgroundElement.style.display = 'none';
        this._backgroundElement.style.position = 'absolute';
        this._backgroundElement.style.top = '0';
        this._backgroundElement.style.left = '0';
        this._backgroundElement.style.zIndex = 10000;
        this._backgroundElement.className = 'mapModalBackground';
        
        e.appendChild(this._backgroundElement);
        
        // IE6 fix background
        if ((Sys.Browser.agent === Sys.Browser.InternetExplorer) && (Sys.Browser.version < 7))
        {
            this._ieFix = document.createElement('iframe');
            this._ieFix.src = 'javascript:"<html></html>";';
            this._ieFix.style.display = 'none';
            this._ieFix.style.position = 'absolute';
            this._ieFix.style.zIndex = 9999;
            this._ieFix.style.top = '0';
            this._ieFix.style.left = '0';
            this._ieFix.scrolling = 'no';
            this._ieFix.frameBorder = '0';
            this._ieFix.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)';
            e.appendChild(this._ieFix);
        }
        
        // Modal
        this._modalElement = document.createElement('div');
        this._modalElement.style.display = 'none';
        this._modalElement.style.position = 'absolute';
        this._modalElement.style.zIndex = 10001;
        this._modalElement.style.top = '0';
        this._modalElement.style.left = '0';
        this._modalElement.className = 'modalElement';

        // Header
        this._headerElement = document.createElement('div');
        this._headerElement.className = 'headerElement';
        this._modalElement.appendChild(this._headerElement);

        // Shadow
        this._shadowElement = document.createElement('div');
        this._shadowElement.className = 'shadowElement';
        this._modalElement.appendChild(this._shadowElement);

        // Info
        this._infoElement = document.createElement('div');
        this._infoElement.className = 'infoElement';
        this._modalElement.appendChild(this._infoElement);

        // Map
        this._mapElement = document.createElement('div');
        this._mapElement.className = 'map mapElement';
        this._modalElement.appendChild(this._mapElement);

        e.appendChild(this._modalElement);

        // Behaviour
        this._mapBehavior = $create(Appian.LargeMapBehavior, this._mapOptions, null, null, this._mapElement);
        this._mapBehavior.loadMap();

        // Handlers
        this._scrollHandler = Function.createDelegate(this, this._onLayout);
        this._resizeHandler = Function.createDelegate(this, this._onLayout);

        // Gets the page header if on a non-standard page. ie. homepage.
//        if (!$get('header'))
//        {
//            // No header, create
//            this._headerElement.id = 'header'; 
//            
//            Appian.Services.UIService.GetMapHeader(Function.createDelegate(this, this._onGetMapHeaderCompleted), 
//                Function.createDelegate(this, this._onGetMapHeaderFailed), 
//                this._headerElement);
//        }

        // Controls
        createInfoPanel(this._infoElement);
    },

//    _onGetMapHeaderCompleted : function(result, control)
//    {
//        control.innerHTML = result;

//        // Search Behaviour   
//        this._searchBehaviour = $create(Appian.SearchBehavior, null, null, null, getElementsByClassName('search', null, control)[0]);
//        
//        this._attachSearch();
//    },

//    _onGetMapHeaderFailed : function(result)
//    {
//        alert(result.get_message());
//    },

    dispose : function() 
    {
        this._detachPopup();

        Appian.MapModal.callBaseMethod(this, 'dispose');
    },

    get_MapOptions : function()
    {
        return this._mapOptions;
    },
    
    set_MapOptions : function(value)
    {
        this._mapOptions = value;
    },
    

    _onLayout : function() 
    {
        this._layout();
    },

    onToggleShow : function()
    {
        !this._isOpen ? this.show(false) : this.hide();
    },

    show: function()
    {
        this._attachPopup();
        this._attachSearch();

        this._backgroundElement.style.display = '';
        this._modalElement.style.display = '';

        if (this._ieFix)
        {
            this._ieFix.style.display = '';
        }

        this._layout();
        this._layout();
        
        this._mapBehavior.updateMap();
        
        // Default infowindow.
        this._mapBehavior.openDefaultItem();
    },

    hide : function()
    {
        this._backgroundElement.style.display = 'none';
        this._modalElement.style.display = 'none';

        if (this._ieFix)
        {
            this._ieFix.style.display = 'none';
        }

        this._detachPopup();
        this._detachSearch();
        
        this._raiseHideCompleted();
    },

    add_Hide : function(handler) 
    {
    	this.get_events().addHandler('hide', handler);
    },

    remove_Hide : function(handler) 
    {
    	this.get_events().removeHandler('hide', handler);
    },

    _raiseHideCompleted : function() 
    {
    	var handlers = this.get_events().getHandler('hide');
    	if (handlers) 
    	{
    		handlers(this, Sys.EventArgs.Empty);
    	}
    },

    _attachPopup : function() 
    {
        $addHandler(window, 'resize', this._resizeHandler);
        $addHandler(window, 'scroll', this._scrollHandler);

        this._isOpen = true;
    },

    _detachPopup : function() 
    {
        if (this._isOpen)
        {
            if (this._resizeHandler) 
            {
                $removeHandler(window, 'resize', this._resizeHandler);
            }
            if (this._scrollHandler) 
            {
                $removeHandler(window, 'scroll', this._scrollHandler);
            }

            this._isOpen = false;
        }
    },
    
    _attachSearch : function()
    {
        if (this._searchBehaviour) 
        {
            __mapSearch = this._searchBehaviour;
        }
    },
    
    _detachSearch : function() 
    {
        if (this._searchBehaviour) 
        {
            this._searchBehaviour.Reset();
            __mapSearch = null;
        }
        else
        {
            $get('header').style.top = 0;
        }
    },

    _layout : function()
    {
        if (!this._isOpen)
        {
            return;
        }
    
        var scrollLeft = (document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft);
        var scrollTop = (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop);
        var clientWidth;
        if (window.innerWidth) 
        {
            clientWidth = ((Sys.Browser.agent === Sys.Browser.Safari) ? window.innerWidth : Math.min(window.innerWidth, document.documentElement.clientWidth));
        } 
        else 
        {
            clientWidth = document.documentElement.clientWidth;
        }
        var clientHeight;
        if (window.innerHeight) 
        {
            clientHeight = ((Sys.Browser.agent === Sys.Browser.Safari) ? window.innerHeight : Math.min(window.innerHeight, document.documentElement.clientHeight));
        } 
        else 
        {
            clientHeight = document.documentElement.clientHeight;
        }

        this._backgroundElement.style.left = scrollLeft + 'px';
        this._backgroundElement.style.top = scrollTop + 'px';
        this._backgroundElement.style.width = clientWidth + 'px';
        this._backgroundElement.style.height = clientHeight + 'px';

        if (this._ieFix)
        {
            this._ieFix.style.left = scrollLeft + 'px';
            this._ieFix.style.top = scrollTop + 'px';
            this._ieFix.style.width = clientWidth + 'px';
            this._ieFix.style.height = clientHeight + 'px';
        }

        this._modalElement.style.width = (clientWidth - this._marginWidth) + 'px';
        this._modalElement.style.height = (clientHeight - this._marginHeight) + 'px';
        //this._modalElement.style.height = (clientHeight - this._marginHeight) - 82 + 'px';
       
        this._modalElement.style.left = scrollLeft + ((clientWidth - this._modalElement.offsetWidth) / 2) + 'px';
        this._modalElement.style.top = scrollTop + ((clientHeight - this._modalElement.offsetHeight) / 2) + 'px';
        //this._modalElement.style.top = (scrollTop + 82) + 'px';

        this._mapElement.style.width = (clientWidth - this._marginWidth) + 'px';
        //this._mapElement.style.height = (clientHeight - this._marginHeight) + 'px';
        this._mapElement.style.height = (clientHeight - this._marginHeight) - 82 + 'px';

        //this._infoElement.style.height = (clientHeight - this._marginHeight - 60) + 'px';
        
        this._shadowElement.style.width = (clientWidth - this._marginWidth) + 'px';

        if (!this._searchBehaviour)
        {
            $get('header').style.top = scrollTop + 'px';
        }

        if (this._mapBehavior)
        {
            this._mapBehavior.resize();
        }
    }
}

Appian.MapModal.registerClass('Appian.MapModal', Sys.UI.Behavior);

/* Map Modal Helper
----------------------------------------------- */

function searchMap(options)
{
    openModalMap(options);
 
     if (_mapModal)
     {
        _mapModal._mapBehavior.set_FeatureData({'Id':0,'FeatureData':options});
     }
}

function openModalMap(options)
{
    if (!_mapModal)
    {
        _mapModal = $create(Appian.MapModal, {'MapOptions':options}, null, null, $get('container'));
        _mapModal.show();
        return true;
    }
    else
    {       
        if (options && options.StreetData) _mapModal._mapBehavior.set_StreetData(options.StreetData);
        if (options && options.Latitude) _mapModal._mapBehavior.set_Latitude(options.Latitude);
        if (options && options.Longitude) _mapModal._mapBehavior.set_Longitude(options.Longitude);
        if (options && options.Zoom) _mapModal._mapBehavior.set_Zoom(options.Zoom);

        //_mapModal.onToggleShow();
        _mapModal.show();
        return false;
    }
}

function closeModalMap()
{
    _mapModal._mapBehavior._featureData = null;
    _mapModal.hide();
}

Sys.Application.add_init(function()
{
    if (window.location.hash == '#map')
    {
        openModalMap({'StreetData' : _streetData});
    }
});

/* Address Rating
----------------------------------------------- */

Appian.AddressRating = function()
{
    this.NeighbourlySpirit = 0;
    this.EatingOut = 0;
    this.Nightlife = 0;
    this.RetailTherapy = 0;
    this.Fitness = 0;
    this.MobilePhoneReception = 0;
    this.InternetAccess = 0;
    this.PayTVAccess = 0;
    this.PeaceAndQuiet = 0;
    this.LackOfTraffic = 0;
    this.SafeAndSound = 0;
    this.CleanAndGreen = 0;
    this.PestFree = 0;
    this.CostOfLiving = 0;
    this.ResaleOrRentalValue = 0;
    this.PublicTransport = 0;
    this.MedicalFacilities = 0;
    this.Schools = 0;
    this.Childcare = 0;
    this.LocalGovernment = 0;
    this.PowerWaterGas = 0;
    this.ParksAndRecreational = 0;
}

Appian.AddressRating.prototype = {}

Appian.AddressRating.registerClass('Appian.AddressRating', null, Sys.IDisposable);

/* -------------------------------------------- */

if(Sys && Sys.Application)
{     
    Sys.Application.notifyScriptLoaded();
}